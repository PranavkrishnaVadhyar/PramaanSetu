# PramaanSetu Synthetic Identity Dataset

This dataset is synthetic test data for the PramaanSetu
document-screening project.

It contains NO real government-issued credentials.

## Structure

person_001/
├── person.json
├── images/
│   └── person.png
├── aadhaar/
│   ├── data.json
│   └── aadhaar.png
├── passport/
│   ├── data.json
│   └── passport.png
└── pan/
    ├── data.json
    └── pan.png

## Generated images

The script generates:

1. A separate synthetic face image.
2. A synthetic Aadhaar-style document.
3. A synthetic passport-style document with MRZ.
4. A synthetic PAN-style document.

The face is deliberately an illustrated synthetic portrait,
not a real person's photograph.

## Positive and negative samples

The dataset intentionally contains both clean and failing documents:

- person_001 to person_003: clean documents; identifiers/checks should pass.
- person_004: printed Aadhaar number is corrupted, QR contains the original
  number, and a visible synthetic edit is added; checksum/QR consistency and
  tampering checks should fail/flag.
- person_005: passport MRZ composite check digit is corrupted and PAN has an
  invalid structure; those validations should fail.

Use the `scenario` field in `validation_summary.json` to build positive and
negative evaluation splits.

## Validation

Aadhaar:
- 12 digits
- Verhoeff-valid
- Synthetic QR payload contains matching fields

Passport:
- TD3-style two-line MRZ
- ICAO 7-3-1 check digits
- Passport number, DOB, expiry and composite check digits
  are internally generated

PAN:
- Matches the project's structural PAN regex

## QR

If the qrcode package is installed, the Aadhaar image contains
a QR code generated from the synthetic qr_payload.

Install:

    pip install pillow qrcode

## Testing PramaanSetu

Use:

    person_001/aadhaar/aadhaar.png
    person_001/passport/passport.png
    person_001/pan/pan.png

as document inputs to Module 1.

Use:

    person_001/images/person.png

as the separate reference image for Module 4.

## Important

All documents and identifiers are synthetic.

Do not represent them as real Aadhaar, PAN or passport
credentials.